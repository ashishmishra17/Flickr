//
//  UserProfileTableViewCell.swift
//  Flickr
//
//  Created by Ashish on 06/12/16.
//  Copyright © 2016 FoodTalkIndia. All rights reserved.
//

import UIKit

class UserProfileTableViewCell: UITableViewCell {
    
    @IBOutlet var imgProfile : UIImageView?
    @IBOutlet var lblEmail : UILabel?
    @IBOutlet var btnLogout : UIButton?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
