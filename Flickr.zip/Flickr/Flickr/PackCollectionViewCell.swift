//
//  PackCollectionViewCell.swift
//  FoodTalk
//
//  Created by Ashish on 08/01/16.
//  Copyright © 2016 FoodTalkIndia. All rights reserved.
//

import UIKit

class PackCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var packCellImage : UIImageView? = UIImageView()

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
