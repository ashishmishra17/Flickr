//
//  PagingViewController.swift
//  Flickr
//
//  Created by Ashish on 07/12/16.
//  Copyright © 2016 FoodTalkIndia. All rights reserved.
//

import UIKit

class PagingViewController: UIViewController, UIScrollViewDelegate {
    
    @IBOutlet var pageControl : UIPageControl?
    @IBOutlet var scrollView : UIScrollView?
    
    var totalPages = 0
    var pagingArray = NSMutableArray()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.backgroundColor = UIColor.darkGray
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if(isPagingFrom == "Home"){
            pagingArray = arrStoredImages
        }
        else{
            pagingArray = arrPublicImages
        }
        totalPages = pagingArray.count
        
        configureScrollView()
        configurePageControl()
    }
    override func viewDidDisappear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
    }
    
    // MARK: Custom method implementation
    
    func configureScrollView() {
        // Enable paging.
        scrollView!.isPagingEnabled = true
        
        // Set the following flag values.
        scrollView!.showsHorizontalScrollIndicator = false
        scrollView!.showsVerticalScrollIndicator = false
        scrollView!.scrollsToTop = false
        self.automaticallyAdjustsScrollViewInsets = false;
        
        // Set the scrollview content size.
        //        scrollView!.contentSize = CGSizeMake(scrollView!.frame.size.width * CGFloat(totalPages), scrollView!.frame.size.height)
        scrollView!.contentSize = CGSize(width: scrollView!.frame.size.width * CGFloat(totalPages),height: 0);
        
        // Set self as the delegate of the scrollview.
        scrollView!.delegate = self
        
        // Load the TestView view from the TestView.xib file and configure it properly.
        for i in 0..<totalPages {
            // Load the TestView view.
            let testView = UIView()
            
            // Set its frame and the background color.
            testView.frame = CGRect(x: CGFloat(i) * scrollView!.frame.size.width, y: scrollView!.frame.origin.y, width: scrollView!.frame.size.width, height: scrollView!.frame.size.height)
            let imgView = UIImageView()
            imgView.frame = CGRect(x: 0, y: 0, width: testView.frame.size.width, height: testView.frame.size.height)
            // Set the proper message to the test view's label.
            if(isPagingFrom == "Home"){
                imgView.image = pagingArray.object(at: i) as? UIImage
            }
            else{
                imgView.image = UIImage(named: pagingArray.object(at: i) as! String)
            }
            imgView.contentMode = UIViewContentMode.scaleAspectFit
            testView.addSubview(imgView)
            // Add the test view as a subview to the scrollview.
            scrollView!.addSubview(testView)
        }
    }
    
    
    func configurePageControl() {
        // Set the total pages to the page control.
        pageControl!.numberOfPages = totalPages
        
        // Set the initial page.
        pageControl!.currentPage = 0
        pageControl!.pageIndicatorTintColor = UIColor.black
    }
    
    
    // MARK: UIScrollViewDelegate method implementation
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        // Calculate the new page index depending on the content offset.
        let currentPage = floor(scrollView.contentOffset.x / UIScreen.main.bounds.size.width);
        
        // Set the new page index to the page control.
        pageControl!.currentPage = Int(currentPage)
    }
    
    
    // MARK: IBAction method implementation
    
    @IBAction func changePage(_ sender: AnyObject) {
        // Calculate the frame that should scroll to based on the page control current page.
        var newFrame = scrollView!.frame
        newFrame.origin.x = newFrame.size.width * CGFloat(pageControl!.currentPage)
        
        scrollView!.scrollRectToVisible(newFrame, animated: true)
        
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
