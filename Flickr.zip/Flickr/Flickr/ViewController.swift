//
//  ViewController.swift
//  Flickr
//
//  Created by Ashish on 06/12/16.
//  Copyright © 2016 FoodTalkIndia. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var email : UITextField?
    @IBOutlet var password : UITextField?
    @IBOutlet var btnSubmit : UIButton?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        btnSubmit?.layer.cornerRadius = 7
        btnSubmit?.layer.borderWidth = 1
        btnSubmit?.layer.borderColor = UIColor.red.cgColor
        
        self.navigationController?.isNavigationBarHidden = true
    }
    
    //MARK:- submitButtonTapped
    
    @IBAction func submitTapped(_ sender : UIButton){
                if((email?.text?.characters.count)! > 0){
                    if((password?.text?.characters.count)! > 0){
                        if(isValidEmail((email?.text)!) == true){
                            let dict = NSMutableDictionary()
                            dict.setObject((email?.text!)! as String, forKey: "email" as NSCopying)
                            dict.setObject((password?.text!)! as String, forKey: "password" as NSCopying)
                            UserDefaults.standard.set(dict, forKey: "userInfo")
                            
                            var tbc : UITabBarController
                            tbc = self.storyboard!.instantiateViewController(withIdentifier: "tabBarVC") as! UITabBarController;
                            tbc.selectedIndex=0;
                            self.dismiss(animated: false, completion: {});
                            self.navigationController?.visibleViewController?.navigationController?.pushViewController(tbc, animated: true)
                        }
                        else{
                            showAlert("Please enter valid email.")
                        }
                    }
                    else{
                        showAlert("Please enter password.")
                    }
                }else{
                    showAlert("Please enter email.")
                }
    }
    
    //MARK:- textfieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func showAlert(_ msg : String){
        let alert = UIAlertController(title: "Oops!", message:msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in })
        self.present(alert, animated: true){}
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

