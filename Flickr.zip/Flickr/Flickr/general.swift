//
//  general.swift
//  Flickr
//
//  Created by Ashish on 06/12/16.
//  Copyright © 2016 FoodTalkIndia. All rights reserved.
//

import Foundation
import UIKit

var colorDefault = UIColor(red: 243/255, green: 177/255, blue: 197/255, alpha: 1.0)
var arrStoredImages = NSMutableArray()
var isPagingFrom = String()

func isValidEmail(_ testStr:String) -> Bool {
    // println("validate calendar: \(testStr)")
    let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
    
    let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
    return emailTest.evaluate(with: testStr)
}
