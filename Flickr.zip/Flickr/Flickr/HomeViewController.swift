//
//  HomeViewController.swift
//  Flickr
//
//  Created by Ashish on 06/12/16.
//  Copyright © 2016 FoodTalkIndia. All rights reserved.
//

import UIKit
import Photos
import AVFoundation

class HomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {

    @IBOutlet var tblView : UITableView?
    var imagesArray = NSMutableArray()
    var imgProfile = UIImageView()
    
    let captureSession = AVCaptureSession()
    let stillImageOutput = AVCaptureStillImageOutput()
    var error: NSError?
    var imagePicker1 = UIImagePickerController()
    var isImageClicked : Bool = false
    var imageSelected = UIImage()
    
    fileprivate let barSize : CGFloat = 44.0
    fileprivate let kCellReuse : String = "PackCell"
    fileprivate let kCellheaderReuse : String = "PackHeader"
    var collectionView : UICollectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewFlowLayout())
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.title = "Home"
        
        tblView!.register(UINib(nibName: "UserProfileTableViewCell", bundle: nil), forCellReuseIdentifier: "UserProfile")
        //  postTableView?.backgroundColor = UIColor(red: 20/255, green: 29/255, blue: 46/255, alpha: 1.0)
        tblView?.backgroundColor = UIColor.white
        tblView?.separatorColor = UIColor.clear
        tblView?.showsHorizontalScrollIndicator = false
        tblView?.showsVerticalScrollIndicator = false
        
        accessCameraRoll()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
       // tblView?.reloadData()
    }
    
    override func viewDidAppear(_ animated: Bool){
          tblView?.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(indexPath.row == 0){
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserProfile", for: indexPath) as! UserProfileTableViewCell
        cell.imgProfile?.layer.borderColor = UIColor.red.cgColor
        cell.imgProfile?.layer.borderWidth = 1
        
        cell.imgProfile?.layer.cornerRadius = 40
        cell.imgProfile?.layer.masksToBounds = true
        cell.imgProfile?.isUserInteractionEnabled = true
        
        imgProfile = cell.imgProfile!
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(HomeViewController.chooseImage))
        tap.numberOfTapsRequired = 1
        cell.imgProfile?.tag = (indexPath as NSIndexPath).row
        cell.imgProfile!.addGestureRecognizer(tap)
            
            cell.btnLogout?.addTarget(self, action: #selector(HomeViewController.logoutTapped(_:)), for: UIControlEvents.touchUpInside)
        if((UserDefaults.standard.object(forKey: "userInfo")) != nil){
        let dict = UserDefaults.standard.object(forKey: "userInfo") as! NSDictionary
        cell.lblEmail?.text = dict.object(forKey: "email") as? String
            }
        return cell
        }
        else{
            var cell = tableView.dequeueReusableCell(withIdentifier: "CELL") as UITableViewCell!
            if (cell == nil) {
                cell = UITableViewCell(style:.default, reuseIdentifier: "CELL")
            }
            cell?.backgroundColor = UIColor.white
            cell?.selectionStyle = UITableViewCellSelectionStyle.none
            
            if(view.viewWithTag(59) == nil){
                if(arrStoredImages.count > 3){
                    self.collectionView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width,height: CGFloat (arrStoredImages.count/3) * self.collectionView.frame.size.width / 3 + UIScreen.main.bounds.size.width / 3)
                }
                else{
                    self.collectionView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width,height: CGFloat (1) * self.collectionView.frame.size.width / 3)
                }
                self.collectionView.delegate = self     // delegate  :  UICollectionViewDelegate
                self.collectionView.dataSource = self   // datasource  : UICollectionViewDataSource
                self.collectionView.tag = 59
                self.collectionView.isScrollEnabled = false
                self.collectionView.backgroundColor = UIColor.clear
                self.collectionView.register(PackCollectionViewCell.self, forCellWithReuseIdentifier: kCellReuse) // UICollectionViewCell
                let nipName=UINib(nibName: "PackCollectionViewCell", bundle:nil)
                
                collectionView.register(nipName, forCellWithReuseIdentifier: "PackCell")
                // UICollectionReusableView
                
                cell?.contentView.addSubview(self.collectionView)
            }
            
            if(arrStoredImages.count > 3){
                self.collectionView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width,height: CGFloat (arrStoredImages.count/3) * self.collectionView.frame.size.width / 3 + UIScreen.main.bounds.size.width / 3)
            }
            else{
                self.collectionView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width,height: CGFloat (1) * self.collectionView.frame.size.width / 3)
            }
            self.collectionView.reloadData()
            
            return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(indexPath.row == 0){
        return 150
        }
        else{
            if(arrStoredImages.count > 0){
                if(arrStoredImages.count < 3){
                    return  1 * self.collectionView.frame.size.width / 3
                }
                return CGFloat (arrStoredImages.count / 3) * self.collectionView.frame.size.width / 3
            }
            else{
                return 350
            }
        }
    }
    
    
    func chooseImage(){
        openPost()
    }
    
    //MARK:- Camera Controls methods
    
    func openPost(){
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
            
            imagePicker.allowsEditing = true
            imagePicker.showsCameraControls = true
            
            addOnImagePicker(imagePicker)
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    @IBAction func openPhotoLibraryButton(_ sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
            
        }
    }
    
    
    func addOnImagePicker(_ imagePicker : UIImagePickerController){
        let viewBlack = UIView()
        viewBlack.frame = CGRect(x: self.view.frame.size.width/2 - 45, y: self.view.frame.size.height - 95, width: self.view.frame.size.width/2 + 40, height: 95)
        viewBlack.backgroundColor = UIColor.black
        viewBlack.tag = 10998
        imagePicker.view.addSubview(viewBlack)
        
        let btnGallary = UIButton(type : .custom)
        btnGallary.frame = CGRect(x: 10, y: 0, width: 80, height: 80)
        btnGallary.addTarget(self, action: #selector(HomeViewController.capture(_:)), for: UIControlEvents.touchUpInside)
        btnGallary.setTitle("", for: UIControlState())
        //   btnGallary.setImage(UIImage(named: "click icon.png"), for: UIControlState())
        btnGallary.setTitle("Click", for: UIControlState.normal)
        btnGallary.tag = 1011
        viewBlack.addSubview(btnGallary)
        
        let btnGallary1 = UIButton(type : .custom)
        btnGallary1.frame = CGRect(x: viewBlack.frame.size.width/2 + 30, y: 0, width: 80, height: 80)
        btnGallary1.addTarget(self, action: #selector(HomeViewController.openPhotoLibraryButton(_:)), for: UIControlEvents.touchUpInside)
        btnGallary1.setTitle("", for: UIControlState())
        //  btnGallary1.setImage(UIImage(named: "gallery Icon.png"), for: UIControlState())
        btnGallary1.setTitle("Gallery", for: UIControlState.normal)
        btnGallary1.tag = 1011
        viewBlack.addSubview(btnGallary1)
        
        imagePicker1 = imagePicker
        imagePicker1.delegate = self
        imagePicker1.allowsEditing = true
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage {
            
            //   let imgFinal = rotateImage(pickedImage)
            imageSelected = resizeImage(pickedImage)
            self.imgProfile.image = imageSelected
            
            isImageClicked = true
            
            self.dismiss(animated: true, completion: nil)
            
        }
            
        else if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            imageSelected = resizeImage(pickedImage)
            self.imgProfile.image = imageSelected
            
            isImageClicked = true
            
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        self.isImageClicked = false
        self.tabBarController?.tabBar.isHidden = false
        self.dismiss(animated: true, completion: nil)
        self.tabBarController?.selectedIndex = 0
    }
    
    func cancel(_ sender : UIButton){
        isImageClicked = false
        self.dismiss(animated: true, completion: nil)
    }
    
    func capture(_ sender : UIButton){
        
        if UIDevice.current.orientation.isLandscape {
            print("landscape")
        } else {
            print("portrait")
        }
        
        imagePicker1.showsCameraControls = true
        imagePicker1.takePicture()
        
        imagePicker1.allowsEditing = true
        imagePicker1.delegate = self
        
        imagePicker1.view.viewWithTag(1009)?.isHidden = true
        imagePicker1.view.viewWithTag(1010)?.isHidden = true
        imagePicker1.view.viewWithTag(1011)?.isHidden = true
        imagePicker1.view.viewWithTag(10998)?.isHidden = true
        
        let viewBlack = UIView()
        viewBlack.frame = CGRect(x: 0, y: self.view.frame.size.height - 70, width: 100, height: 90)
        viewBlack.backgroundColor = UIColor.clear
        // viewBlack.alpha = 0.7
        viewBlack.tag = 10910
        imagePicker1.view.addSubview(viewBlack)
        
        let btnGallary = UIButton(type : .custom)
        btnGallary.frame = CGRect(x: 10, y: 0, width: 80, height: 80)
        btnGallary.addTarget(self, action: #selector(HomeViewController.retake(_:)), for: UIControlEvents.touchUpInside)
        btnGallary.setTitle("", for: UIControlState())
        btnGallary.tag = 101100
        viewBlack.addSubview(btnGallary)
        
    }
    
    func rotateImage(_ image: UIImage) -> UIImage {
        
        
        let portraitImage  : UIImage = UIImage(cgImage: image.cgImage! ,
                                               scale: 1.0 ,
                                               orientation: UIImageOrientation.right)
        return portraitImage
    }
    
    func retake(_ sender : UIButton){
        sender.superview!.viewWithTag(1009)?.isHidden = false
        sender.superview!.viewWithTag(1010)?.isHidden = false
        sender.superview!.viewWithTag(1011)?.isHidden = true
        sender.superview!.viewWithTag(10998)?.isHidden = false
        sender.superview!.viewWithTag(10910)?.isHidden = true
        sender.superview!
            .viewWithTag(101100)?.isHidden = true
        
        dismiss(animated: true, completion: nil)
    }
    
    func resizeImage(_ image : UIImage) -> UIImage
    {
        var actualHeight = image.size.height as CGFloat;
        var actualWidth = image.size.width as CGFloat;
        let maxHeight = 1080.0 as CGFloat
        let maxWidth = 1080.0 as CGFloat
        var imgRatio = actualWidth/actualHeight;
        let maxRatio = maxWidth/maxHeight;
        let compressionQuality = 0.1 as CGFloat;//50 percent compression
        
        if (actualHeight > maxHeight || actualWidth > maxWidth)
        {
            if(imgRatio < maxRatio)
            {
                //adjust width according to maxHeight
                imgRatio = maxHeight / actualHeight;
                actualWidth = imgRatio * actualWidth;
                actualHeight = maxHeight;
            }
            else if(imgRatio > maxRatio)
            {
                //adjust height according to maxWidth
                imgRatio = maxWidth / actualWidth;
                actualHeight = imgRatio * actualHeight;
                actualWidth = maxWidth;
            }
            else
            {
                actualHeight = maxHeight;
                actualWidth = maxWidth
            }
        }
        
        let rect = CGRect(x: 0.0, y: 0.0, width: actualWidth, height: actualHeight);
        UIGraphicsBeginImageContext(rect.size);
        image.draw(in: rect);
        let img = UIGraphicsGetImageFromCurrentImageContext();
        let imageData = UIImageJPEGRepresentation(img!, compressionQuality);
        UIGraphicsEndImageContext();
        
        return UIImage(data: imageData!)!;
        //      return image
        
    }
    
    //MARK:- collectionViewDelegate
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell : PackCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: kCellReuse, for: indexPath) as! PackCollectionViewCell
        if(arrStoredImages.count > 0){
            
            cell.packCellImage?.image = arrStoredImages.object(at: indexPath.row) as? UIImage
            
        }
        return cell    // Create UICollectionViewCell
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1  // Number of section
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrStoredImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        isPagingFrom = "Home"
        let openPost = self.storyboard!.instantiateViewController(withIdentifier: "Paging") as! PagingViewController;
        self.navigationController!.visibleViewController!.navigationController!.pushViewController(openPost, animated:true);
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        return CGSize(width: (UIScreen.main.bounds.size.width/3 - 1), height: (UIScreen.main.bounds.size.width/3 - 1));
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0.80
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0.80
    }


    
    func accessCameraRoll(){
        
    }
    
    func logoutTapped(_ sender : UIButton){
        let alertController = UIAlertController(title: "", message: "", preferredStyle: .alert)
        
        let attrubuted = NSMutableAttributedString(string: "Are you sure want to logout?")
        attrubuted.addAttribute(NSFontAttributeName, value: UIFont.boldSystemFont(ofSize: 16), range: NSMakeRange(0, 28))
        alertController.setValue(attrubuted, forKey: "attributedTitle")
        
        let okAction = UIAlertAction(title: "Yes", style: UIAlertActionStyle.default) {
            UIAlertAction in
            
            UserDefaults.standard.set(nil, forKey: "userInfo")
            let openPost = self.storyboard!.instantiateViewController(withIdentifier: "ViewController") as! ViewController;
            self.navigationController?.present(openPost, animated: true, completion: nil)
            
        }
        let cancelAction = UIAlertAction(title: "No", style: UIAlertActionStyle.cancel) {
            UIAlertAction in
            NSLog("Cancel Pressed")
        }
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
