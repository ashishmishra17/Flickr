//
//  MoreViewController.swift
//  Flickr
//
//  Created by Ashish on 06/12/16.
//  Copyright © 2016 FoodTalkIndia. All rights reserved.
//

import UIKit

var arrPublicImages = NSMutableArray()

class MoreViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var tblView : UITableView?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        arrPublicImages.addObjects(from: ["download.jpeg","images (1).jpeg","images (2).jpeg","images (3).jpeg","winter.jpg"])
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrPublicImages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "CELL") as UITableViewCell!
        
        cell = UITableViewCell(style:.default, reuseIdentifier: "CELL")
        cell?.backgroundColor = UIColor.darkGray
        
        let imgView = UIImageView()
        imgView.frame = CGRect(x: 2, y: 2, width : (cell?.frame.size.width)! - 4, height: 96)
        imgView.image = UIImage(named : (arrPublicImages.object(at: indexPath.row) as! String))
        imgView.contentMode = UIViewContentMode.scaleToFill
        cell?.contentView.addSubview(imgView)
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        isPagingFrom = "More"
        let openPost = self.storyboard!.instantiateViewController(withIdentifier: "Paging") as! PagingViewController;
        self.navigationController!.pushViewController(openPost, animated:true);
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
